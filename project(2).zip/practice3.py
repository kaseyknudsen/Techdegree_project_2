bike_rides = [
    {'Street': 'Trestle Glen', 'Date': '1.19', 'Time': '10:21'}, 
    {'Street': 'Trestle Glen', 'Date': '1.18', 'Time': '10:18'},
    {'Street': 'Trestle Glen', 'Date': '1.17', 'Time': '10:21'},
    {'Street': 'Trestle Glen', 'Date': '1.16', 'Time': '10:05'}
]

#for ride in bike_rides:
#    print("Street:", ride['Street'])
#    print(", ".join(ride['Time'].split()))
    
    
def average_time(**kwargs):
    for key, value in kwargs.items():
        print(f'{key}: {value}')
        
average_time(Street='Trestle Glenn', Date='1.19', Time='10:19')