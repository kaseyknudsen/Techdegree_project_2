trestle_glenn = [
             {'Date': '1.10', 'Time': '10:14'}, 
             {'Date': '1.13', 'Time': '10:16'},
             {'Date': '1.14', 'Time': '10:10'}
                ]

for time in trestle_glenn:
    print(f"Date: {time['Date']}  Time: {time['Time']}")
    
    
#def print_date_and_time(street_times):
#    for times in street_times:
#        time = int(times['Time'].split())
#        print(time)
#        if times['Time'] != '10:00':
#            times['Time'] = 'too slow!'
#    print(street_times)
#        
#print_date_and_time(trestle_glenn)
#    
#    
##print(trestle_glenn[0])
#
##first_entry = trestle_glenn[0]['Date']
##print(first_entry)
#
#second_entry = trestle_glenn[1]['Time']
#print(second_entry)