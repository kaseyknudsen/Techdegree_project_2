students = [
    {"name": "Jennifer", "techdegree": "Python"},
    {"name": "Amber", "techdegree": "FEWD"}
]
def print_students(student_list):
    print("=" * 20)
    for student in student_list:
        print(f"Name: {student['name']} Techdegree: {student['techdegree']}")
# print students before we change them to Python
print_students(students)
# Change everyone to Python
for student in students:
    if student['techdegree'] != "Python": #if the student's techdegree isn't Python
        student['techdegree'] = "Python"  # change it to "Python"
# print students after they're all in Python
print_students(students)



#tunnel_road = [
#    {'Date': '1/31/21', 'Time': '22:36'},
#    {'Date': '1/27/21', 'Time': '22:47'},
#    {'Date': '1/23/21', 'Time': '22:58'},
#    {'Date': '1/3/21', 'Time': '24:03'} 
#     ]
#
#def average_time(list_of_times):
#    for time in list_of_times:
#        rider_time = time['Time'].split(':')
#        minutes = int(rider_time[0])
#        seconds = int(rider_time[1])
#        minutes_to_seconds = minutes * 60
#        total_seconds = seconds + minutes_to_seconds
#        average = float(total_seconds / 60)
#        print(average)
#        
#        
#        if time['Time'] != '22:00':
#                time['Time'] = 'Too Slow!'
#        
#    #print(list_of_times)
#    
#    
#average_time(tunnel_road)    
#    




#As far as turning the "40 inches" to just a 40 might I suggest splitting on the space, which results in ["40", "inches"], then grabbing the first item [0] and turning that into an int?  Maybe something like:  player['height'] = 
#int(player['height'].split()[0]) 



        
        
        
        
        
#a = "40 inches"
#print(a)
#b = a.split()
#print(b)
#c = b[0]
#print(c)
#print(type(c))
#d = int(c)
#print(d)
#print(type(d))