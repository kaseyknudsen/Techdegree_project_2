import constants
import copy

players_copy = copy.deepcopy(constants.PLAYERS)

if players_copy['experience'] == 'YES':
    print(True)

if __name__ == '__main__':
    def print_players(players):
        for player in players:
            print(f"Name: {player['name']}\nGuardians: {player['guardians']}\nExperience: {player['experience']}\nHeight: {player['height']}\n")
            
print_players(players_copy)                 
                