my_list = [['Hyman Krustofski', 'Rachel Krustofski'], ['Jim Smith', 'Jan Smith'], ['Robin Soto', 'Sarika Soto'], ['Wendy Martin', 'Mike Gordon'], ['Aaron Lanning', 'Jill Finkelstein'], ['Bill Stein', 'Hillary Stein']]  

parents = []

for list in my_list:
    for guardian in list:
        parents.append(guardian)

print(", ".join(parents))        
                   

                                                                                                                                                                                          