import constants
import copy
import sys
#
players_copy = copy.deepcopy(constants.PLAYERS)
teams_copy = copy.deepcopy(constants.TEAMS)
#
Panthers = []
#Bandits = []
#Warriors = []
#
num_players_per_team = int(len(players_copy) / len(teams_copy))
#
#print("""
#Welcome to Basketball Teams Stat Tool!
#      
#-----MENU-----
#""")
#
#
#def clean_data():
#    for player in players_copy:
#        height = player['height'].split()
#        height = int(height[0])
#    for player in players_copy:
#        experience = player['experience']
#        if experience == 'YES':
#            experience = True
#        else:
#            experience = False
#                
#
#def balance_teams():
#    for player in players_copy:
#        player_name = player['name']
#        if len(Panthers) < num_players_per_team:
#            Panthers.append(player_name)
#        elif len(Bandits) < num_players_per_team:
#            Bandits.append(player_name)
#        elif len(Warriors) < num_players_per_team:
#            Warriors.append(player_name)
#            
def balance_teams2():
    Panthers_Team = [player for player in players_copy if len(Panthers) < num_players_per_team]
    print(Panthers)
    
balance_teams2()            
            
#            
#            
#
#def display_stats():
#    balance_teams()
#    user_choice = input("Enter (A) for team stats or (B) to quit:  ")
#    if user_choice == 'A':
#        team_choice = input("\nEnter (A) for Warriors. Enter (B) for Bandits. Enter (C) for Panthers:  ")
#        team_A = 'Warriors'
#        team_B = 'Bandits'
#        team_C = 'Panthers'
#        if team_choice == 'A':
#            print("\n","-" * 10 + " Number of players on team: {} ".format(num_players_per_team) + "-" * 10)
#            print(f"\nHere are your {team_A}: ", ", ".join(Warriors),"\n")
#        elif team_choice == 'B':
#            print("\n","-" * 10 + " Number of players on team: {} ".format(num_players_per_team) + "-" * 10)
#            print(f"\nHere are your {team_B}: ", ", ".join(Bandits), "\n")
#        elif team_choice == 'C':
#            print("\n","-" * 10 + " Number of players on team: {} ".format(num_players_per_team) + "-" * 10)
#            print(f"\nHere are your {team_C}: ", ", ".join(Panthers), "\n")
#    elif user_choice == 'B':
#        print("\nThanks for visiting the Basketball Teams Stats Tool!\n")
#        sys.exit()
#            
#
#display_stats()
#
#
#    
#
#    
#
#    
#    
#      
#        
#    
